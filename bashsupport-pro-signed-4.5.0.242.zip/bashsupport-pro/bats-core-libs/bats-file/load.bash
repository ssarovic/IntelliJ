# shellcheck source=./src/file.bash
source "$(dirname "${BASH_SOURCE[0]}")/src/file.bash"
# shellcheck source=./src/temp.bash
source "$(dirname "${BASH_SOURCE[0]}")/src/temp.bash"
