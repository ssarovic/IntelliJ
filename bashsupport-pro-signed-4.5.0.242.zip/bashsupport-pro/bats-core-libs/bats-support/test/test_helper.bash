setup() {
  export TEST_MAIN_DIR="${BATS_TEST_DIRNAME}/.."

  # Load library.
  load '../load'
}
