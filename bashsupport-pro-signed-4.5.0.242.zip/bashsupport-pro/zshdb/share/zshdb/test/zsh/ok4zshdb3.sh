# 3rd part of is-ok-debug test
fc -l fdafdsa 2>/dev/null
