# 2nd part of is-ok-debug test
:
